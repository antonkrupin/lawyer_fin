module.exports = {
  theme: {
    // Some useful comment
  },
  variants: {
    // Some useful comment
  },
  plugins: [
    // Some useful comment
  ]
}
